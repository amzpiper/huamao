var hm_dispatch_work_order = StudioWidgetWrapper.extend({
  /*
   * Triggered when initializing a widget and will have the code that invokes rendering of the widget
   */
  init: function () {
    var thisObj = this;
    thisObj._super.apply(thisObj, arguments);
    thisObj.render();
    if ((typeof (Studio) != "undefined") && Studio) {
      /*
       * Register custom event or action here, and trigger the event afterwards.
       * Studio.registerEvents(thisObj, "", "", EventConfig), 
       * Studio.registerAction(thisObj, "", "", ActionConfig, $.proxy(this.Cbk, this), );
       * thisObj.triggerEvent("", )
       */
    }
  },

  /*
   * Triggered from init method and is used to render the widget
   */
  render: function () {
    var thisObj = this;
    var widgetProperties = thisObj.getProperties();
    var elem = thisObj.getContainer();
    var items = thisObj.getItems();
    var connectorProperties = thisObj.getConnectorProperties();

    /*
     * API to get base path of your uploaded widget API file
     */
    var widgetBasePath = thisObj.getWidgetBasePath();
    if (elem) {

      thisObj.vm = new Vue({
        el: $("#hm_dispatch_work_order", elem)[0],
        data(){
          return{
            img: "",
            name: "",
            summary: "",
            dispatch_arr:[],
            l:'' //数组长度
          }
          
        },
        created() {
          // 表格显示5行数据，此处复制开头的5条数据实现无缝
         
        },
        mounted() {
        //  this.queryOffering();
        //   this.InsertKeyframes();
        this.renderData()
        setInterval(()=>{
          this.renderData()
        },60000)
        },
        methods: {
          async renderData(){
            await this.queryOffering();
            this.InsertKeyframes();
          },
          InsertKeyframes(){
              if(this.l>5){
                let row = -this.l * 80;
                console.log("row",row)
                var scrollLength = row
                var style = document.styleSheets[0];
                style.insertRule(`.dispatch_list {
                  animation: dispatch_scroll ${(this.l+5) * 2}s  linear infinite;
                  position: relative;
                }`,0);
                 console.log(style);
                style.insertRule(`@keyframes dispatch_scroll {from { top: 0; } to { top: ${scrollLength}px }}`,0);//写入样式
              }
            },
          // async queryOffering() {
          queryOffering() {
            return new Promise(resolve=>{
              thisObj.callFlowConn("APIBridge", {
                service: "hm_bigScreen__HMSecurityManagement/1.0.0/dispatchOrder"
              }, {
                testField: "A"
              }, result => {
                console.log(result)
                  this.dispatch_arr = result.data[0].listData;
                  this.l = this.dispatch_arr.length;
                  console.log("长度",this.l)
                  if(this.l>5){
                    this.dispatch_arr = this.dispatch_arr.concat(this.dispatch_arr.slice(0, 5))
                  }
                  resolve()
              })
             
            })
  
            // debugger
           
          }
        }
      })
    }

    /*
     * API to bind global events to the item DOM, it should not be deleted if there will some events to trigger in this widget.
     */
    thisObj.sksBindItemEvent();

    /*
     * API to refresh the previously bound events when a resize or orientation change occurs.
     */
    $(window).resize(function () {
      thisObj.sksRefreshEvents();
    });
  },

  callFlowConn: function (connectorName, inputParam, param, cbk, errorCbk) {
    var thisObj = this;
    var connector = thisObj.getConnectorInstanceByName(connectorName);
    if (connector) {
      connector.setInputParams(inputParam);
      connector.query(param)
        .done(result => {
          cbk && cbk.call(thisObj, result);
        }).fail(function (err) {
          errorCbk && errorCbk.call(thisObj, result);
        })
    }
  },
});